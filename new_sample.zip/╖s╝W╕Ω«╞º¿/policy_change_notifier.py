policy changes notifier
from wfbsh_util import parse_config
from wfbsh_util import getLogger
from wfbsh_policy_changes_notifier import tasks
from wfbsh_util import batch_iter
from wfbsh_policy_changes_notifier.client import PolicyNotifierClient
from uuid import UUID
from wfbsh_system import DEFAULT_DC_INI

logger = getLogger(name)

decorator
def check_policy_notifier_enabled(func):
def warp(*args, **kw):
if not PolicyChangesNotifier.is_enable():
return
return func(*args, **kw)
return warp

migration decorator: temporarily disable policy change notification for (migration) script
def handle_policy_notifier_for_migration(func):
def warp(*args, **kw):
if PolicyChangesNotifier.is_enable():
logger.info(“[handle_policy_notifier_for_migration] start policy migration”)
PolicyChangesNotifier.disable_for_migration()
try:
func(*args, **kw)
except Exception as e:
logger.info(“[handle_policy_notifier_for_migration] got error during migration. error msg: %s”, e.message)
finally:
PolicyChangesNotifier.resume_for_migration()
logger.info(“[handle_policy_notifier_for_migration] end policy migration”)
else:
func(*args, **kw)
return warp

migration decorator:
for ut env, as there is no MQ setup, always disable, and not resume
for production, the change notification can be properly handled, run as is
def handle_policy_notifier_for_ut_migration(func):
def warp(*args, **kw):
dc_ini = parse_config(DEFAULT_DC_INI)
env = dc_ini[‘DC’][‘environment’].strip()
if env == ‘ut’:
logger.info(“[handle_policy_notifier_for_ut_migration] start policy migration - force disable policy change notification in ut env”)
PolicyChangesNotifier.disable_for_migration()
func(*args, **kw)
else:
func(*args, **kw)
return warp

class PolicyChangesNotifier(object):
__config = parse_config(‘/opt/trendmicro/etc/policy_changes_notifier.ini’)

__enable = bool(int(__config['policy_changes_notifier']['enable_policy_notifier']))
__notify_target_urls = __config['policy_changes_notifier']['policy_notification_tagets_urls'].split(",")
__batch_size_cids = int(__config['policy_changes_notifier']['batch_size_cids'])
__task_normal_countdown_exponential_sec = int(__config['policy_changes_notifier']['task_normal_countdown_exponential_sec'])
__task_rescue_countdown_sec = int(__config['policy_changes_notifier']['task_rescue_countdown_sec'])

TYPE_DOMAIN_POLICY_CHANGED = "domain policy changed"  # Domain.domain_policy_mt
TYPE_IAC_RULES_CHANGED = "iac rules changed"  # IACRules.changed_at
TYPE_DEVICE_CONTROL_GLOBAL_SETTINGS_CHANGED = "device control global settings changed"  # DCGlobalSettings.changed_at
TYPE_SO_GLOBAL_SETTINGS_CHANGED = "so global setting changed"  # SOGlobalSettings.changed_at
TYPE_FEATURE_FLAG_SETTINGS_CHANGED = "feature flag domain setting changed"  # from feature flag (LaunchDarkly) result
TYPE_DOMAIN_ENCRYPTION_EXPDATE_CHANGED = "domain encryption expdate changed"  # Domain.encryption_expdate
TYPE_MB_POLICY_APPLIED_DEVICES_CHANGED = "policy applied devices changed (MB)"  # (MB) Computer.resolved_pid
TYPE_SB_POLICY_APPLIED_DEVICES_CHANGED = "policy applied devices changed (SB)"  # (SB) Computer group changed
TYPE_POLICY_DETAIL_CHANGED = "policy detail changed"  # Policy.policy_windows.changed_at, Policy.policy_mac.changed_at
TYPE_IVP_PATTERN_CHANGED = "ivp pattern changed"  # ivp filer
TYPE_SEG_CONSOLE_FORCE_NOTIFY = "seg console force notify"
TYPE_MIGRATION_NOTIFY = "notify all after migration"
TYPE_SB_GROUP_NAME_CHANGED = "group name changed (SB)"

@classmethod
@check_policy_notifier_enabled
def notify_domain(cls, notify_type, notify_did):
    payload = {'did': notify_did, 'notify_type': notify_type}
    logger.debug("notify to domain: (%s), payload: %s", notify_type, payload)
    for url in cls.__notify_target_urls:
        tasks.notify_policy_changes_to_endpoint.delay(url, payload)

@classmethod
@check_policy_notifier_enabled
def notify_computers(cls, notify_type, notify_did, notify_cids):
    notify_cids_str = []
    for cid in notify_cids:
        if isinstance(cid, str):
            notify_cids_str.append(cid)
        elif isinstance(cid, UUID):
            logger.error("notify_computers with cid parameter not string (is UUID): %r, %r" % (cid, notify_cids))
            notify_cids_str.append(str(cid))
        else:
            logger.error("notify_computers with cid parameter not string: %r, %r" % (cid, notify_cids))
            # NOTE: enable this in UT to find potential issue
            #raise Exception("notify_computers with cid parameter not string: %r" % cid)
    for cutting_cids in batch_iter(notify_cids_str, cls.__batch_size_cids):
        payload = {'did': notify_did, 'cids': cutting_cids, 'notify_type': notify_type}
        logger.debug("notify to computers: (%s), payload: %s", notify_type, payload)
        for url in cls.__notify_target_urls:
            tasks.notify_policy_changes_to_endpoint.delay(url, payload)

@classmethod
@check_policy_notifier_enabled
def notify_all_domains(cls, notify_type):
    payload = {'notify_type': notify_type}
    logger.debug("notify to all domain: (%s), payload: %s", notify_type, payload)
    for url in cls.__notify_target_urls:
        tasks.notify_policy_changes_to_endpoint.delay(url, payload)

"""
force notify endpoint by sync code
"""
@classmethod
@check_policy_notifier_enabled
def force_notify_for_seg(cls, notify_did, notify_cids):
    payload = {"notify_type": PolicyChangesNotifier.TYPE_SEG_CONSOLE_FORCE_NOTIFY}
    if notify_did:
        payload["did"] = notify_did
    if notify_cids:
        payload["cids"] = notify_cids

    result = []
    for url in cls.__notify_target_urls:
        try:
            PolicyNotifierClient.notify_to_endpoint(url, payload)
            result.append({"is_success": True, "url": url})
        except Exception as e:
            result.append({"is_success": False, "url": url, "error_msg": e.message})
    return result


@classmethod
def is_enable(cls):
    return cls.__enable

@classmethod
def get_task_normal_countdown_exponential_sec(cls):
    return cls.__task_normal_countdown_exponential_sec

@classmethod
def get_task_rescue_countdown_sec(cls):
    return cls.__task_rescue_countdown_sec

@classmethod
def disable_for_migration(cls):
    cls.__enable = False
    logger.info('[PolicyNotifier] force disable policy notifier for migration')

@classmethod
def resume_for_migration(cls):
    logger.info('[PolicyNotifier] resume from config & notify all domains.')
    cls.__enable = cls.__config['policy_changes_notifier']['enable_policy_notifier']
    cls.notify_all_domains(PolicyChangesNotifier.TYPE_MIGRATION_NOTIFY)
選擇 Repo