ivp_manager.py
import time

from wfbsh_feature_flag.feature_flag_manager import FeatureFlagManager
from wfbsh_protobuf import log_pb2 as LOG
from wfbsh_protobuf.def_pb2 import Def
from wfbsh_dbal.database import DatabaseManager
from wfbsh_util import getLogger
from wfbsh_util import json2gpb
from wfbsh_util.util import get_shardid
from wfbsh_util import del_value_at_dict_path, get_value_at_dict_path
from wfbsh_ivp.ivp_pattern_manager import IVPPatternManager

log = getLogger(name)

class IVPNotSupport(Exception): pass

class IVPTemplate(object):
def init(self, sid, did):
self.sid = sid
self.did = did

def create_ivp_policy_ref(self, *argv, **kwargs):
    raise NotImplemented

def dump_windows_ivp_policy(self, *argv, **kwargs):
    raise NotImplemented

def get_decrypted_ivp_pattern_content_and_version(self, *argv, **kwargs):
    raise NotImplemented

def validate_pb_logq_related_type(self, *argv, **kwargs):
    raise NotImplemented

def relayout_ivp_policy(self, *argv, **kwargs):
    raise NotImplemented

def validate_ivp_policy_patch(self, *argv, **kwargs):
    raise NotImplemented

def validate_ivp_policy_section(self, *argv, **kwargs):
    raise NotImplemented

def validate_ivp_log_populate(self, *argv, **kwargs):
    raise NotImplemented

def relayout_pb_component_list(self, *argv, **kwargs):
    raise NotImplemented

def get_rule_list(self, *argv, **kwargs):
    raise NotImplemented
class IVPManager(IVPTemplate):
def init(self, sid, did):
IVPTemplate.init(self, sid, did)
self.ptn_mgr = IVPPatternManager()

def create_ivp_policy_ref(self, expected_policy_ref, static_res_url, refid_ver, ekey_ts, cpt_version):
    sha1_hash = self.ptn_mgr.get_sha1_by_cpt_version(cpt_version)
    expected_policy_ref.domain_ivp_pattern_url = (static_res_url + '{0}-{1}-{2}-{3}'.format(
            refid_ver, 'ivp', self.did, 'reserved_%s_%s' % (sha1_hash, ekey_ts)))

def dump_windows_ivp_policy(self, dst_p, src_p):
    json2gpb(dst_p.ivp, src_p.ivp)
    if dst_p.ivp.enabled:
        dst_p.desktop_active_components |= Def.COMP_IVP
        dst_p.server_active_components |= Def.COMP_IVP

def get_decrypted_ivp_pattern_content_and_version(self, sha1_hash):
    return self.ptn_mgr.get_pattern_detail_by_sha1(sha1_hash)

def validate_pb_logq_related_type(self, logq):
    pass

def relayout_ivp_policy(self, policy):
    # workaround: replace migration script
    if get_value_at_dict_path(policy, 'win.ivp.enabled') is not None:
        policy['win']['ivp']['enabled'] = int(policy['win']['ivp']['enabled'])

def validate_ivp_policy_patch(self, patch_for_policy):
    pass

def validate_ivp_policy_section(self, section):
    pass

def validate_ivp_log_populate(self):
    pass

def relayout_pb_component_list(self, pb_compnts):
    # Since the current iVP pattern is manually added,
    # the pattern version number will be temporarily hard coded,
    # and it will be revised after changing to the AU mechanism.
    version = self.ptn_mgr.get_current_version()
    comp_type_list = [comp['type'] for comp in pb_compnts['component']]
    if Def.CT_PTN_IVP not in comp_type_list:
        pb_compnts['component'].append({
            'last_update_time': int(time.time()),
            'version': version, # always show the latest version
            'type': Def.CT_PTN_IVP
        })

def get_rule_list(self):
    return self.ptn_mgr.get_current_rulelist()
class IVPDoNothing(IVPTemplate):
def init(self, sid, did):
IVPTemplate.init(self, sid, did)

def create_ivp_policy_ref(self, expected_policy_ref, static_res_url, refid_ver, ekey_ts, cpt_version):
    pass

def dump_windows_ivp_policy(self, dst_p, src_p):
    dst_p.ClearField('ivp')

def get_decrypted_ivp_pattern_content_and_version(self, sha1_hash):
    # After discuss with agent team, if domain ivp feature flag is False, then return empty string.
    log.info('Does not have authorization to get decrypted ivp pattern. did(%r)', self.did)
    return '', ''

def validate_pb_logq_related_type(self, logq):
    if logq.params.log_type == LOG.LogType.IVP or \
       LOG.LogType.IVP in logq.params.related.log_types:
        log.error('did(%r) domain_attrs.feature_flag.wfbss-ivp is None or 0, so it cannot retrieve ivp section(win.ivp).', self.did)
        raise IVPNotSupport('validate_pb_logq_related_type did %r' % self.did)

def relayout_ivp_policy(self, policy):
    del_value_at_dict_path(policy, 'win.ivp')

def validate_ivp_policy_patch(self, patch_for_policy):
    if get_value_at_dict_path(patch_for_policy, 'win.ivp') is not None:
        log.error('did(%r) domain_attrs.feature_flag.wfbss-ivp is None or 0, so it cannot retrieve ivp section(win.ivp).', self.did)
        raise IVPNotSupport('validate_ivp_policy_patch did %r' % self.did)

def validate_ivp_policy_section(self, p_section):
    if p_section == 'win.ivp':
        log.error('did(%r) domain_attrs.feature_flag.wfbss-ivp is None or 0, so it cannot retrieve ivp section(win.ivp).', self.did)
        raise IVPNotSupport('validate_ivp_policy_section did %r' % self.did)

def validate_ivp_log_populate(self):
    log.error('did(%r) domain_attrs.feature_flag.wfbss-ivp is None or 0, so it cannot retrieve ivp section(win.ivp).', self.did)
    raise IVPNotSupport('validate_ivp_log_populate did %r' % self.did)

def relayout_pb_component_list(self, pb_compnts):
    # to delete iVP component dictionary in list
    comp_list = [comp for comp in pb_compnts['component'] if comp['type'] not in [Def.CT_PRD_IVP, Def.CT_PTN_IVP]]
    pb_compnts['component'] = comp_list

def get_rule_list(self):
    log.error('did(%r) wfbss-ivp is False', self.did)
    raise IVPNotSupport('get_rule_list did %r' % self.did)
class IVPManagerFactory(object):
def new(cls, sid, did):
if sid is None:
sid, _, _, _ = get_shardid(did=did)

    with DatabaseManager(sid, 'ro') as dbm:
        ivp_feature_flag = dbm.run(FeatureFlagManager.get_feature_flag, did, 'wfbss-ivp')

    if ivp_feature_flag:
        return IVPManager(sid, did)
    else:
        return IVPDoNothing(sid, did)
選擇 Repo
