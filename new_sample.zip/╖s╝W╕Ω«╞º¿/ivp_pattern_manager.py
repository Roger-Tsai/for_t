ivp_pattern_manager.py
import os
import glob
import time
import threading

import wfbsh_ivp as IVP
from wfbsh_ivp.util import transfer_ivp_rule_list_to_json

from wfbsh_util import getLogger, compare_version
from wfbsh_util.filer import get_ivp_pattern_dir
from wfbsh_util.cryptoutil import aes_decrypt
from wfbsh_policy_changes_notifier.policy_changes_notifiable import PolicyChangesNotifiable
from wfbsh_policy_changes_notifier.policy_changes_notifier import PolicyChangesNotifier, check_policy_notifier_enabled

log = getLogger(name)

class IVPPatternManager(PolicyChangesNotifiable):
_instance = None
_last_update_time = int(time.time())
default_pattern = None
current_pattern = None
_old_new_pattern_boundary = ‘6.7.1374’
_singleton_lock = threading.Lock()

def __new__(cls, *args, **kwargs):
    if not cls._instance:
        with cls._singleton_lock:
            cls._instance = super(IVPPatternManager, cls).__new__(cls, *args, **kwargs)
            cls._instance._instance_initialize()
    return cls._instance

def __init__(self):
    now = int(time.time())
    if self._last_update_time + IVP.pattern_ttl < now:
        # sync filer when it has been more than one hour since the last update
        self.sync_pattern_from_filer()
        self._last_update_time = now

@check_policy_notifier_enabled
def notify_policy_changes_to_domain(self, notify_type, **_):
    PolicyChangesNotifier.notify_all_domains(notify_type)

@check_policy_notifier_enabled
def notify_policy_changes_to_computers(self, notify_type, **_):
    pass

def _instance_initialize(self):
    now = int(time.time())
    self.default_pattern = self._load_default_pattern()
    self.current_pattern = self.default_pattern
    # sync filer when first instance initialing to assure get the latest pattern from
    self.sync_pattern_from_filer()
    self._last_update_time = now

# default pattern will change maybe every two weeks or every month
# v1 for old windows agents (agent version <  6.7.1374)
# v2 for new windows agents (agent version >= 6.7.1374)
def _load_default_pattern(self):
    result = {
        'pattern_filename_v1': '',
        'pattern_content_v1': '',
        'pattern_sha1_hash_v1': '',
        'pattern_version_v1': '',
        'pattern_filename_v2': '',
        'pattern_content_v2': '',
        'pattern_sha1_hash_v2': '',
        'pattern_version_v2': '',
        'rulelist_filename_v2': '',
        'rulelist_json_v2': ''
    }
    pattern_path_v1 = '/opt/trendmicro/var/pattern/ivp/v1/'
    pattern_path_v2 = '/opt/trendmicro/var/pattern/ivp/v2/'

    # get default pattern file v1
    list_of_pattern_files = glob.glob(pattern_path_v1 + '*.ptn')
    latest_filepath = max(list_of_pattern_files, key=os.path.getmtime)
    filename = os.path.basename(latest_filepath)
    version, raw_sha1, enc_sha1 = filename[:-4].split('_')
    result['pattern_filename_v1'] = filename
    result['pattern_content_v1'] = self._get_content_by_path(latest_filepath)
    result['pattern_sha1_hash_v1'] = enc_sha1
    result['pattern_version_v1'] = version

    # get default pattern file v2
    list_of_pattern_files = glob.glob(pattern_path_v2 + '*.ptn')
    latest_filepath = max(list_of_pattern_files, key=os.path.getmtime)
    filename = os.path.basename(latest_filepath)
    version, raw_sha1, enc_sha1 = filename[:-4].split('_')
    result['pattern_filename_v2'] = filename
    result['pattern_content_v2'] = self._get_content_by_path(latest_filepath)
    result['pattern_sha1_hash_v2'] = enc_sha1
    result['pattern_version_v2'] = version

    # get default rulelist file v2
    list_of_pattern_files = glob.glob(pattern_path_v2 + '*.csv')
    latest_filepath = max(list_of_pattern_files, key=os.path.getmtime)
    filename = os.path.basename(latest_filepath)
    result['rulelist_filename_v2'] = filename
    result['rulelist_json_v2'] = transfer_ivp_rule_list_to_json(latest_filepath)

    return result

def _get_content_by_path(self, filepath):
    with open(filepath, 'rb') as f:
        return f.read()

def get_sha1_by_cpt_version(self, cpt_version):
    # use new pattern
    if compare_version(cpt_version, self._old_new_pattern_boundary) >= 0:
        if self.current_pattern:
            return self.current_pattern['pattern_sha1_hash_v2']
        else:
            return self.default_pattern['pattern_sha1_hash_v2']
    else:
        return self.default_pattern['pattern_sha1_hash_v1']

def get_current_version(self):
    if self.current_pattern:
        return self.current_pattern['pattern_version_v2']
    else:
        return self.default_pattern['pattern_version_v2']

def get_current_rulelist(self):
    if self.current_pattern:
        return self.current_pattern['rulelist_json_v2']
    else:
        return self.default_pattern['rulelist_json_v2']

def get_pattern_detail_by_sha1(self, sha1_hash):
    # return decrypted pattern content and its version if the sha1_hash existed in memory cache
    if sha1_hash == self.current_pattern['pattern_sha1_hash_v1']:
        return aes_decrypt(IVP.key, IVP.iv, self.current_pattern['pattern_content_v1']), self.current_pattern['pattern_version_v1']
    if sha1_hash == self.current_pattern['pattern_sha1_hash_v2']:
        return aes_decrypt(IVP.key, IVP.iv, self.current_pattern['pattern_content_v2']), self.current_pattern['pattern_version_v2']

    # return decrypted pattern content and its version if the sha1_hash is the same as default pattern
    if sha1_hash == self.default_pattern['pattern_sha1_hash_v2']:
        return aes_decrypt(IVP.key, IVP.iv, self.default_pattern['pattern_content_v2']), self.default_pattern['pattern_version_v2']

    # return decrypted pattern content and its version if the sha1_hash existed in filer
    ivp_pattern_dir = get_ivp_pattern_dir()
    path_filter = os.path.join(ivp_pattern_dir, '*_{0}*.ptn'.format(sha1_hash))
    selected_files = glob.glob(path_filter)
    if selected_files:
        encrypted_pattern_content = self._get_content_by_path(selected_files[0])
        filename = os.path.basename(selected_files[0])
        state, version, raw_sha1, enc_sha1 = filename[:-4].split('_')
        return aes_decrypt(IVP.key, IVP.iv, encrypted_pattern_content), version
    else:
        log.error('No matching iVP pattern file found with sha1:%r', sha1_hash)
        raise Exception('No matching iVP pattern file found with sha1:%r', sha1_hash)

def sync_pattern_from_filer(self):
    # get the selected iVP pattern from filer
    ivp_pattern_dir = get_ivp_pattern_dir()
    path_filter = os.path.join(ivp_pattern_dir, 'selected_*')
    selected_files = glob.glob(path_filter)

    if selected_files:
        # refresh memory when selected pattern changed
        if self.current_pattern['pattern_filename_v2'] not in selected_files:
            for f in selected_files:
                extension = f[-3:]
                filename = f.split('/')[-1][:-4]

                # pattern file
                if extension == 'ptn':
                    _, pattern_version, raw_pattern_sha1, encrypted_pattern_sha1 = filename.split('_')

                    # refresh varible
                    self.current_pattern['pattern_filename_v2'] = '{0}.{1}'.format(filename, extension)
                    self.current_pattern['pattern_content_v2'] = self._get_content_by_path(f)
                    self.current_pattern['pattern_sha1_hash_v2'] = encrypted_pattern_sha1
                    self.current_pattern['pattern_version_v2'] = pattern_version

                # rule list file
                elif extension == 'csv':
                    self.current_pattern['rulelist_filename_v2'] = '{0}.{1}'.format(filename, extension)
                    self.current_pattern['rulelist_json_v2'] = transfer_ivp_rule_list_to_json(f)

    # use default pattern as current use
    else:
        self.current_pattern = self.default_pattern

    self.notify_policy_changes_to_domain(PolicyChangesNotifier.TYPE_IVP_PATTERN_CHANGED)
選擇 Repo